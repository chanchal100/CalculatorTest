import { AppRegistry } from 'react-native';
import ReactCalculator from './src/ReactCalculator';

